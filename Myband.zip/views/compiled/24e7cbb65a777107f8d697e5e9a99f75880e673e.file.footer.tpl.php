<?php /* Smarty version Smarty-3.1.18, created on 2016-09-28 14:16:46
         compiled from "views\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:775057ebcba829a6d7-11209273%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '24e7cbb65a777107f8d697e5e9a99f75880e673e' => 
    array (
      0 => 'views\\footer.tpl',
      1 => 1475072201,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '775057ebcba829a6d7-11209273',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57ebcba835b530_99644971',
  'variables' => 
  array (
    'footertekst' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ebcba835b530_99644971')) {function content_57ebcba835b530_99644971($_smarty_tpl) {?><footer>

    <p style="text-align: center;"><?php echo $_smarty_tpl->tpl_vars['footertekst']->value;?>
</p>

</footer>
</body>
</html><?php }} ?>
