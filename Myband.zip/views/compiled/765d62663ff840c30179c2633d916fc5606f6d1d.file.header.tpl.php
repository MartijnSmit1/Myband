<?php /* Smarty version Smarty-3.1.18, created on 2016-10-12 14:42:54
         compiled from "views\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:245557fe2fced13ba9-83056896%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '765d62663ff840c30179c2633d916fc5606f6d1d' => 
    array (
      0 => 'views\\header.tpl',
      1 => 1476276168,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '245557fe2fced13ba9-83056896',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57fe2fced38ca6_85859726',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57fe2fced38ca6_85859726')) {function content_57fe2fced38ca6_85859726($_smarty_tpl) {?><nav>
    <ul>
        <li><a href="?action=home">Home</a></li>
        <li><a href="?action=about">About</a></li>
    </ul>
</nav><?php }} ?>
