<?php /* Smarty version Smarty-3.1.18, created on 2016-10-12 14:34:50
         compiled from "views\about.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3024257fe2dea11bb78-26984697%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca421bab107b2b775730a59672b523b524b4180f' => 
    array (
      0 => 'views\\about.tpl',
      1 => 1476274933,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3024257fe2dea11bb78-26984697',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_57fe2dea1bc863_64268022',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57fe2dea1bc863_64268022')) {function content_57fe2dea1bc863_64268022($_smarty_tpl) {?><h1>About Me</h1>

<p>This A ABOUT.tpl Homework</p><?php }} ?>
